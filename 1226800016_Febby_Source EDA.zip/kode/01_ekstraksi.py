# -*- coding: utf-8 -*-
"""Langkah 01 - dari DATA MENTAH (citra + label VIA JSON) ke tabel per citra.
Keluaran: 01_citra.csv (satu baris per citra), 01_cakupan.csv (satu baris per kondisi)."""
import glob
import json
import os
import random

import cv2
import numpy as np
import pandas as pd

import config as C
from common import *


def baca_label():
    """{(kelas, warna, posisi, pwm): {nama_citra_kecil: (luas_bbox_px, n_region, n_titik)}}"""
    index, catatan = {}, []
    for jf in sorted(glob.glob(os.path.join(C.LBL_DIR, "**", "*.json"), recursive=True)):
        try:
            with open(jf, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            catatan.append((os.path.basename(jf), f"gagal dibaca: {e}"))
            continue
        if not isinstance(data, dict):
            catatan.append((os.path.basename(jf), "bukan format VIA"))
            continue
        meta = meta_from_json_name(jf)
        for kunci, item in data.items():
            if not isinstance(item, dict) or "regions" not in item:
                continue
            nama = item.get("filename") or kunci
            regs = item["regions"]
            regs = list(regs.values()) if isinstance(regs, dict) else list(regs)
            luas, n_reg, n_pt, kelas_isi = 0.0, 0, 0, None
            for r in regs:
                sa = r.get("shape_attributes", {})
                if not sa.get("all_points_x"):
                    continue
                x, y = np.asarray(sa["all_points_x"], float), np.asarray(sa["all_points_y"], float)
                luas += (x.max() - x.min()) * (y.max() - y.min())
                n_reg += 1
                n_pt = max(n_pt, len(x))
                teks = str(r.get("region_attributes", {}).get("label", "")).lower()
                kelas_isi = kelas_isi or next((k for k in KELAS if k in teks), None)
            if n_reg == 0:
                continue
            if meta:
                key = meta
            else:                                   # cadangan: metadata dari isi JSON
                w, p, pw = parse_meta(nama)
                key = (kelas_isi, w, p, pw)
                if None in key:
                    catatan.append((os.path.basename(jf), f"metadata tidak terbaca: {nama}"))
                    continue
            index.setdefault(key, {})[nama.lower()] = (luas, n_reg, n_pt)
    return index, catatan


def pindai_citra(index):
    rng = random.Random(C.SEED)
    baris, cakupan = [], []
    for fk, kk in SIZE_FOLDERS.items():
        kd = os.path.join(C.IMG_DIR, fk)
        if not os.path.isdir(kd):
            print(f"[PERINGATAN] folder tidak ditemukan: {kd}")
            continue
        for sub in sorted(os.listdir(kd)):
            sd = os.path.join(kd, sub)
            if not os.path.isdir(sd):
                continue
            w, p, pw = parse_meta(sub)
            if None in (w, p, pw):
                print(f"[LEWATI] nama folder tidak dikenali: {fk}/{sub}")
                continue
            files = sorted(glob.glob(os.path.join(sd, "*.jpg")) + glob.glob(os.path.join(sd, "*.png")))
            lab = index.get((kk, w, p, pw), {})
            ada = {os.path.basename(f).lower() for f in files}
            cakupan.append(dict(ukuran_kelas=KELAS[kk], warna_bg=w.capitalize(), posisi_lampu=POSISI[p], pwm_cahaya=pw,
                                n_citra=len(files), n_label_json=len(lab), n_label_cocok=sum(k in ada for k in lab)))
            pilih = files
            if C.SAMPLE_PER_FOLDER and len(files) > C.SAMPLE_PER_FOLDER:
                pilih = rng.sample(files, C.SAMPLE_PER_FOLDER)
            for f in pilih:
                img = cv2.imread(f)
                if img is None:
                    print("[PERINGATAN] gagal dibaca:", f)
                    continue
                h, wd = img.shape[:2]
                g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                lap = cv2.Laplacian(g, cv2.CV_64F).var()
                terang = float(g.mean())
                luas, n_reg, n_pt = lab.get(os.path.basename(f).lower(), (0.0, 0, 0))
                baris.append(dict(filename=os.path.basename(f), ukuran_kelas=KELAS[kk], warna_bg=w.capitalize(),
                                  posisi_lampu=POSISI[p], pwm_cahaya=pw, img_w=wd, img_h=h, blur_score=lap,
                                  brightness=terang, blur_norm=lap / (terang ** 2 + 1e-6),
                                  box_count=n_reg, box_area_px=luas, n_titik=n_pt if n_reg else np.nan))
            print(f"   {KELAS[kk]:<17}{sub:<16} citra={len(files):>5} label={len(lab):>5}")
    return pd.DataFrame(baris), pd.DataFrame(cakupan)


if __name__ == "__main__":
    print("[01] membaca label JSON dari", C.LBL_DIR)
    index, catatan = baca_label()
    print("   kondisi berlabel:", len(index), "| catatan:", catatan[:5])
    print("[01] memindai citra dari", C.IMG_DIR)
    df, cov = pindai_citra(index)
    if df.empty:
        raise SystemExit("Tidak ada citra terbaca; periksa IMG_DIR di config.py")
    simpan_csv(df, "01_citra.csv")
    simpan_csv(cov, "01_cakupan.csv")
    print(f"[01] selesai: {len(df):,} citra, {int((df.box_area_px > 0).sum()):,} berlabel")
