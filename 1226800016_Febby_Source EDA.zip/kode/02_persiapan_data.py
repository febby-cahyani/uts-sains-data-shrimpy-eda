# -*- coding: utf-8 -*-
"""Langkah 02 - persiapan data (Bagian B): missing value, outlier, transformasi, unit analisis, split.
Masukan : 01_citra.csv   Keluaran: 02_frame_siap.csv, 02_kondisi.csv, 02_split_kondisi.csv, B_*.csv, B_*.png"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

import config as C
from analisis import agregasi_kondisi
from common import *

df = pd.read_csv(path_out("01_citra.csv"))
df["warna_bg"] = df["warna_bg"].str.strip().str.capitalize()
if "brightness" not in df:                                   # CSV lama tanpa kolom kecerahan
    r = df["blur_score"] / df["blur_norm"].replace(0, np.nan)
    df["brightness"] = np.sqrt((r - 1e-6).clip(lower=0))
if "n_titik" not in df:
    p = path_out("eda_luas_polygon_per_frame.csv")
    if os.path.exists(p):
        nt = pd.read_csv(p, usecols=["filename", "n_titik"])
        nt["k"] = nt["filename"].str.lower()
        df["k"] = df["filename"].str.lower()
        df = df.merge(nt[["k", "n_titik"]].drop_duplicates("k"), on="k", how="left").drop(columns="k")
    else:
        df["n_titik"] = np.nan
N_ALL = len(df)

# ---------------- turunan dasar ----------------
df["ada_label"] = df["box_area_px"] > 0
df["box_area_frac"] = np.where(df["ada_label"], df["box_area_px"] / (df["img_w"] * df["img_h"]), np.nan)
df["frame_no"] = df["filename"].str.extract(r"_(\d+)\.[A-Za-z0-9]+$")[0].astype(float)
df["kond_id"] = df[KOND].astype(str).agg("|".join, axis=1)

# ---------------- 1) MISSING VALUE ----------------
miss = pd.DataFrame([
    ("Label polygon (luas box)", int((~df["ada_label"]).sum()), "Dikecualikan per analisis (bukan diimputasi)"),
    ("Blur score", int(df["blur_score"].isna().sum()), "Tidak ada yang hilang"),
    ("Kecerahan", int(df["brightness"].isna().sum()), "Tidak ada yang hilang"),
    ("Jumlah titik polygon", int(df.loc[df["ada_label"], "n_titik"].isna().sum()) if df["n_titik"].notna().any() else N_ALL,
     "Hanya dipakai untuk sensitivitas"),
], columns=["variabel", "n_hilang", "penanganan"])
miss["persen"] = 100 * miss["n_hilang"] / N_ALL
simpan_csv(miss, "B_missing_audit.csv")

# ---------------- 2) OUTLIER ----------------
lab = df[df["ada_label"]]
q = lab.groupby("ukuran_kelas")["box_area_frac"].quantile([0.25, 0.75]).unstack()
q.columns = ["q1", "q3"]
q["lo"], q["hi"] = q["q1"] - C.IQR_K * (q["q3"] - q["q1"]), q["q3"] + C.IQR_K * (q["q3"] - q["q1"])
df["flag_iqr_out"] = df["ada_label"] & ((df["box_area_frac"] < df["ukuran_kelas"].map(q["lo"])) | (df["box_area_frac"] > df["ukuran_kelas"].map(q["hi"])))
df["flag_ekstrem"] = df["ada_label"] & (df["box_area_frac"] > C.EKSTREM_FRAC)
rw, rh = C.RES_STANDAR or tuple(df.groupby(["img_w", "img_h"]).size().idxmax())
df["flag_res"] = ~((df["img_w"] == rw) & (df["img_h"] == rh))
df["flag_kasar"] = df["n_titik"].fillna(99) <= 5
df["pakai_area"] = df["ada_label"] & ~df["flag_ekstrem"]            # keputusan utama: buang hanya yang diduga salah label

# ---------------- 3) TRANSFORMASI ----------------
df["log_area"] = np.where(df["pakai_area"], np.log(df["box_area_frac"].where(df["pakai_area"], 1.0)), np.nan)
df["log_blur"] = np.log(df["blur_score"].clip(lower=1e-3))
df["log_blur_norm"] = np.log(df["blur_norm"].clip(lower=1e-8))


def ringkas(s):
    s = s.dropna()
    return dict(n=len(s), mean=s.mean(), median=s.median(), sd=s.std(), skew=float(stats.skew(s)), kurtosis=float(stats.kurtosis(s)))


sa = df[df["pakai_area"]]
sb = pd.DataFrame([
    dict(variabel="Luas box relatif", tahap="sebelum (mentah)", **ringkas(sa["box_area_frac"])),
    dict(variabel="Luas box relatif", tahap="sesudah (log)", **ringkas(sa["log_area"])),
    dict(variabel="Blur score", tahap="sebelum (mentah)", **ringkas(df["blur_score"])),
    dict(variabel="Blur score", tahap="sesudah (log)", **ringkas(df["log_blur"])),
])
simpan_csv(sb, "B_sebelum_sesudah.csv")
rng = np.random.default_rng(C.SEED)
for nama, raw, lg, judul in [("luas", sa["box_area_frac"], sa["log_area"], "Luas box relatif"), ("blur", df["blur_score"], df["log_blur"], "Blur score")]:
    fig, ax = plt.subplots(1, 4, figsize=(17, 3.6))
    ax[0].hist(raw.dropna(), bins=60, color="#9A91DC"); ax[0].set_title(f"{judul}: sebelum (mentah)")
    ax[1].hist(lg.dropna(), bins=60, color="#4A3FAE"); ax[1].set_title(f"{judul}: sesudah (log)")
    for a, s, t in [(ax[2], raw, "QQ sebelum"), (ax[3], lg, "QQ sesudah")]:
        s = s.dropna().to_numpy()
        s = s[rng.choice(len(s), min(5000, len(s)), replace=False)]
        stats.probplot(s, dist="norm", plot=a); a.set_title(t)
    plt.tight_layout(); plt.savefig(path_out(f"B_sebelum_sesudah_{nama}.png"), dpi=170); plt.close()
    print("   gambar:", f"B_sebelum_sesudah_{nama}.png")

# ---------------- 4) KETERGANTUNGAN ANTAR FRAME ----------------
ac = []
for kid, g in df.groupby("kond_id"):
    g = g.sort_values("frame_no")
    if len(g) >= 30 and g["frame_no"].notna().all():
        ga = g[g["pakai_area"]]
        ac.append(dict(kond_id=kid, n=len(g), rho_blur=g["log_blur"].autocorr(1),
                       rho_area=ga["log_area"].autocorr(1) if len(ga) >= 30 else np.nan))
ac = pd.DataFrame(ac)
if len(ac):
    ac["n_efektif_blur"] = ac["n"] * (1 - ac["rho_blur"].clip(0, 0.99)) / (1 + ac["rho_blur"].clip(0, 0.99))
simpan_csv(ac, "B_autokorelasi.csv")
rho_med = float(ac["rho_blur"].median()) if len(ac) else np.nan
neff_med = float(ac["n_efektif_blur"].median()) if len(ac) else np.nan
n_med = float(ac["n"].median()) if len(ac) else np.nan

# ---------------- 5) UNIT ANALISIS + SPLIT PER KONDISI ----------------
kond = agregasi_kondisi(df)
simpan_csv(kond, "02_kondisi.csv")
elig = kond[kond["n_label"] >= C.N_MIN_LABEL][KOND + ["n_label"]].copy()
split = []
for c, g in elig.groupby("ukuran_kelas"):
    g = g.sample(frac=1, random_state=C.SEED).reset_index(drop=True)
    n = len(g)
    nv, nt_ = int(round(C.SPLIT_PROP[1] * n)), int(round(C.SPLIT_PROP[2] * n))
    g["split"] = ["validation"] * nv + ["test"] * nt_ + ["train"] * (n - nv - nt_)
    split.append(g)
split = pd.concat(split) if split else pd.DataFrame(columns=KOND + ["n_label", "split"])
simpan_csv(split, "02_split_kondisi.csv")
df = df.merge(split[KOND + ["split"]], on=KOND, how="left")
df["split"] = df["split"].fillna("tanpa_label")
simpan_csv(df, "02_frame_siap.csv")

audit = pd.DataFrame([
    ("Kondisi muncul di lebih dari satu split", int((split.groupby(KOND)["split"].nunique() > 1).sum()) if len(split) else 0),
    ("Nama citra muncul di lebih dari satu split", int((df[df["split"] != "tanpa_label"].groupby("filename")["split"].nunique() > 1).sum())),
    ("Kondisi layak split (>= N_MIN_LABEL frame berlabel)", len(split)),
    ("Frame train / validation / test", " / ".join(f"{int((df['split'] == s).sum()):,}" for s in ("train", "validation", "test"))),
], columns=["pemeriksaan", "hasil"])
simpan_csv(audit, "B_split_audit.csv")

# ---------------- 6) TABEL KEPUTUSAN (apa, mengapa, risiko) ----------------
n_unl, n_ek, n_iq = int((~df["ada_label"]).sum()), int(df["flag_ekstrem"].sum()), int(df["flag_iqr_out"].sum())
n_res, n_kas = int(df["flag_res"].sum()), int(df["flag_kasar"].sum())
sk = {(r.variabel, r.tahap): r.skew for r in sb.itertuples()}
cls = df.groupby("ukuran_kelas").size().reindex(URUT)
keputusan = pd.DataFrame([
    ("Label hilang", f"{n_unl:,} frame ({100 * n_unl / N_ALL:.1f}%)", "Dikecualikan per analisis, tidak diimputasi",
     "Luas box tidak bisa dihitung tanpa label; imputasi membuat data buatan. Uji blur tidak butuh label sehingga tetap memakai semua frame.",
     "Kesimpulan ukuran objek tidak berlaku untuk kondisi tanpa label (mis. Hitam, Hijau-Atas)."),
    ("Outlier ekstrem (box > %d%% frame)" % int(C.EKSTREM_FRAC * 100), f"{n_ek:,} frame", "Dikeluarkan dari analisis ukuran",
     "Box yang menutup separuh frame hampir pasti salah label.", "Bisa membuang pose valid; diuji pada sensitivitas."),
    ("Outlier IQR (k=%.1f)" % C.IQR_K, f"{n_iq:,} frame", "Dipertahankan; analisis memakai median per kondisi",
     "Variasi pose dan jarak udang adalah variasi nyata; median tahan terhadap nilai ekstrem.",
     "Jika sebagian adalah salah label, median bergeser sedikit; diuji pada sensitivitas S1."),
    ("Sebaran miring", f"skew luas {sk[('Luas box relatif', 'sebelum (mentah)')]:.2f} -> {sk[('Luas box relatif', 'sesudah (log)')]:.2f}; "
     f"blur {sk[('Blur score', 'sebelum (mentah)')]:.2f} -> {sk[('Blur score', 'sesudah (log)')]:.2f}",
     "Transformasi log", "Menstabilkan skala dan membuat selisih menjadi rasio yang mudah ditafsirkan.", "Hasil dibaca sebagai rasio, bukan selisih absolut."),
    ("Resolusi tidak standar", f"{n_res:,} citra ({100 * n_res / N_ALL:.1f}%)", "Memakai luas relatif terhadap frame",
     "Skala piksel berbeda antar resolusi.", "Blur score tetap bergantung resolusi; diuji pada sensitivitas S2."),
    ("Frame berurutan", f"rho lag-1 median {rho_med:.2f}; n efektif median {neff_med:.0f} dari {n_med:.0f} frame/kondisi",
     "Unit analisis = kondisi (agregasi)", "Frame bersebelahan tidak independen; uji tingkat frame menggembungkan signifikansi.",
     "Jumlah unit berkurang (puluhan kondisi); kuasa uji lebih rendah."),
    ("Polygon kasar (<= 5 titik)", f"{n_kas:,} frame", "Dipertahankan; luas = bounding box polygon",
     "Bounding box sebanding antar kelas walau halus-kasarnya label berbeda.", "Diuji pada sensitivitas S4."),
    ("Kelas tidak seimbang", ", ".join(f"{k.split()[0]} {int(v):,}" for k, v in cls.items()), "Tiap kondisi berbobot sama",
     "Agregasi ke kondisi menyamakan sumbangan tiap kelas.", "Kondisi dengan sedikit frame punya estimasi kurang stabil (filter N_MIN_LABEL)."),
    ("Rencana split", f"{len(split)} kondisi layak", "Split per kondisi, stratifikasi per kelas",
     "Mencegah kebocoran antar frame berurutan.", "Kondisi berbeda dari rekaman yang sama bisa serupa; dicatat sebagai keterbatasan."),
], columns=["isu", "bukti", "keputusan", "alasan", "risiko"])
simpan_csv(keputusan, "B_keputusan.csv")
print(f"[02] selesai: {N_ALL:,} frame; resolusi standar {rw}x{rh}; {len(kond)} kondisi; split per kondisi dibuat")
