# -*- coding: utf-8 -*-
"""Langkah 03 - analisis lanjutan (Bagian C): uji hipotesis dari temuan EDA. Unit analisis = KONDISI.
H1: luas box relatif terurut Small < Medium < Large.      (temuan EDA: median 4,3% -> 7,9% -> 13,4% luas frame)
H2: lampu Bawah menaikkan skor ketajaman; apakah bertahan setelah kecerahan dinormalkan?
H3: lampu Bawah vs Atas TIDAK menggeser luas box lebih dari +-TOST_MARGIN (ekuivalensi; relevan bagi pengukuran panjang)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats

import config as C
from analisis import uji_h1, uji_h2, uji_h3
from common import *

k = pd.read_csv(path_out("02_kondisi.csv"))
sns.set_theme(style="whitegrid")
h1, h2, h3 = uji_h1(k), uji_h2(k), uji_h3(k)
baris, asumsi, ring = [], [], []


def tambah(hip, subset, n, est, lo, hi, p, efek, nilai, kes, arti="", ci_arti=""):
    baris.append(dict(hipotesis=hip, subset=subset, n=n, estimasi=est, arti_estimasi=arti, ci_lo=lo, ci_hi=hi, arti_ci=ci_arti, p=p, ukuran_efek=efek, nilai_efek=nilai, kesimpulan=kes))


# ---------------- H1 ----------------
if h1:
    tambah("H1 omnibus (Kruskal-Wallis)", "3 kelas", sum(h1["n"]), h1["H"], np.nan, np.nan, h1["p"], "epsilon^2", h1["eps2"],
           "ada perbedaan" if h1["p"] < C.ALPHA else "tidak ada bukti perbedaan", arti="statistik H")
    tambah("H1 tren terurut (Jonckheere-Terpstra)", "S<M<L", sum(h1["n"]), h1["jt_z"], np.nan, np.nan, h1["jt_p"], "-", np.nan,
           "tren naik" if h1["jt_p"] < C.ALPHA else "tidak ada bukti tren", arti="z")
    pp = [x["p"] for x in h1["pair"]]
    adj = holm(pp)
    for x, pa in zip(h1["pair"], adj):
        tambah("H1 pasangan kelas (Mann-Whitney, Holm)", f"{x['b'].split()[0]} vs {x['a'].split()[0]}", "-", x["rasio_median"], np.nan, np.nan, pa,
               "Cliff's delta", x["cliffs_delta"], "beda" if pa < C.ALPHA else "tidak beda", arti="rasio median (kelas besar / kecil)", ci_arti="CI95% Cliff's delta")
        baris[-1]["ci_lo"], baris[-1]["ci_hi"] = x["d_lo"], x["d_hi"]   # CI untuk Cliff's delta
    for c, g, m in zip(URUT, h1["grup"], h1["medians"]):
        asumsi.append(dict(hipotesis="H1", pemeriksaan=f"n kondisi & Shapiro-Wilk log-median, {c}", hasil=f"n={len(g)}; p={stats.shapiro(np.log(g)).pvalue:.3f}"))
    asumsi.append(dict(hipotesis="H1", pemeriksaan="Homogenitas varians (Brown-Forsythe, log)", hasil=f"p={h1['levene_p']:.3f}"))
    ring.append(f"H1: median luas box relatif per kondisi = " + "; ".join(f"{c.split()[0]} {100 * m:.1f}% frame" for c, m in zip(URUT, h1["medians"]))
                + f". Kruskal-Wallis p={h1['p']:.2g}, epsilon^2={h1['eps2']:.2f}; tren Jonckheere-Terpstra p={h1['jt_p']:.2g}. "
                + "Efek antar pasangan (Cliff's delta): " + "; ".join(f"{x['b'].split()[0]}>{x['a'].split()[0]} {x['cliffs_delta']:.2f}" for x in h1["pair"]) + ".")
else:
    ring.append("H1: jumlah kondisi berlabel per kelas kurang dari 3; turunkan N_MIN_LABEL di config.py.")

# ---------------- H2 ----------------
p2 = []
for nama in ("mentah", "ternormalkan"):
    for sub in ["semua"] + URUT:
        r = h2[nama][sub]
        p2.append(r["p"])
adj2 = holm(p2)
i = 0
for nama in ("mentah", "ternormalkan"):
    for sub in ["semua"] + URUT:
        r = h2[nama][sub]
        tambah(f"H2 ketajaman {nama} (Wilcoxon berpasangan, Holm)", sub if sub == "semua" else sub.split()[0], r["n"], r["rasio"], r["ci_lo"], r["ci_hi"], adj2[i],
               "rank-biserial r", r["r_rb"], "Bawah > Atas" if (adj2[i] < C.ALPHA and r["rasio"] > 1) else ("Bawah < Atas" if (adj2[i] < C.ALPHA and r["rasio"] < 1) else "tidak beda"), arti="rasio median Bawah/Atas", ci_arti="CI95% rasio")
        i += 1
    asumsi.append(dict(hipotesis="H2", pemeriksaan=f"Shapiro-Wilk selisih berpasangan ({nama})", hasil=f"p={h2[nama]['semua']['shapiro_p']:.3f}; n pasangan={h2[nama]['semua']['n']}"))
a, b = h2["mentah"]["semua"], h2["ternormalkan"]["semua"]
ring.append(f"H2: lampu Bawah vs Atas pada skor ketajaman mentah = {a['rasio']:.2f}x (CI95% {a['ci_lo']:.2f}-{a['ci_hi']:.2f}; n={a['n']} pasangan; Wilcoxon p={a['p']:.2g}; r={a['r_rb']:.2f}); "
            f"setelah dinormalkan kecerahan = {b['rasio']:.2f}x (CI95% {b['ci_lo']:.2f}-{b['ci_hi']:.2f}; p={b['p']:.2g}; r={b['r_rb']:.2f}).")

# ---------------- H3 ----------------
for sub in ["semua"] + URUT:
    r = h3[sub]
    tambah(f"H3 ekuivalensi lampu (TOST Wilcoxon, margin +-{100 * C.TOST_MARGIN:.0f}%)", sub if sub == "semua" else sub.split()[0], r["n"], r["rasio"], r["ci90_lo"], r["ci90_hi"], r["p_tost"],
           "CI90% dalam margin?", r["ekuivalen_ci"], "ekuivalen" if r["ekuivalen_ci"] is True else ("tidak terbukti ekuivalen" if r["ekuivalen_ci"] is False else "data kurang"), arti="rasio median luas box Bawah/Atas", ci_arti="CI90% rasio")
d3 = h3["d"].to_numpy()
if len(d3) >= 6:
    asumsi.append(dict(hipotesis="H3", pemeriksaan="Shapiro-Wilk & skewness selisih (simetri untuk Wilcoxon)", hasil=f"p={stats.shapiro(d3).pvalue:.3f}; skew={stats.skew(d3):.2f}; n pasangan={len(d3)}"))
r = h3["semua"]
ring.append(f"H3: rasio median luas box Bawah/Atas = {r['rasio']:.3f} (CI90% {r['ci90_lo']:.3f}-{r['ci90_hi']:.3f}; n={r['n']} pasangan) terhadap margin +-{100 * C.TOST_MARGIN:.0f}% -> "
            + ("ekuivalen." if r["ekuivalen_ci"] is True else "ekuivalensi tidak terbukti." if r["ekuivalen_ci"] is False else "data kurang."))

hasil = pd.DataFrame(baris)
simpan_csv(hasil, "C_hasil_uji.csv")
simpan_csv(pd.DataFrame(asumsi), "C_asumsi.csv")
open(path_out("C_ringkasan.md"), "w", encoding="utf-8").write("# Ringkasan hasil uji (otomatis)\n\n" + "\n\n".join(ring) + "\n")
print("   ringkasan: C_ringkasan.md")

# ---------------- gambar ----------------
if h1:
    d = k.dropna(subset=["median_area_frac"]).copy()
    d["pct"] = 100 * d["median_area_frac"]
    plt.figure(figsize=(7, 4.5))
    sns.boxplot(data=d, x="ukuran_kelas", y="pct", order=URUT, color="#DCE4FF", showfliers=False)
    sns.stripplot(data=d, x="ukuran_kelas", y="pct", order=URUT, color="#4A3FAE", size=4, alpha=0.7)
    plt.xlabel(""); plt.ylabel("median luas box per kondisi (% luas frame)"); plt.title("H1: satu titik = satu kondisi")
    plt.tight_layout(); plt.savefig(path_out("C_H1_median_per_kelas.png"), dpi=180); plt.close()
fig, ax = plt.subplots(1, 2, figsize=(11, 3.8), sharey=True)
for a_, nama in zip(ax, ("mentah", "ternormalkan")):
    dd = h2[nama]["d"].to_numpy()
    if len(dd):
        a_.hist(np.exp(dd), bins=25, color="#36a970"); a_.axvline(1, color="k", ls="--")
        a_.axvline(h2[nama]["semua"]["rasio"], color="#C2185B"); a_.set_title(f"H2 ({nama}): rasio Bawah/Atas per pasangan kondisi"); a_.set_xlabel("rasio")
plt.tight_layout(); plt.savefig(path_out("C_H2_selisih_berpasangan.png"), dpi=180); plt.close()
fig, a_ = plt.subplots(figsize=(7, 3.6))
for j, sub in enumerate(["semua"] + URUT):
    r = h3[sub]
    if r["n"] >= 6:
        a_.errorbar(100 * (r["rasio"] - 1), j, xerr=[[100 * (r["rasio"] - r["ci90_lo"])], [100 * (r["ci90_hi"] - r["rasio"])]], fmt="o", color="#4A3FAE", capsize=4)
a_.axvspan(-100 * C.TOST_MARGIN, 100 * C.TOST_MARGIN, color="#DCE4FF", alpha=0.7); a_.axvline(0, color="k", lw=0.8)
a_.set_yticks(range(4)); a_.set_yticklabels(["semua"] + [c.split()[0] for c in URUT]); a_.invert_yaxis()
a_.set_xlabel("selisih median luas box, Bawah vs Atas (%), CI90%"); a_.set_title(f"H3: margin ekuivalensi +-{100 * C.TOST_MARGIN:.0f}%")
plt.tight_layout(); plt.savefig(path_out("C_H3_ekuivalensi.png"), dpi=180); plt.close()
print("   gambar: C_H1_median_per_kelas.png, C_H2_selisih_berpasangan.png, C_H3_ekuivalensi.png")
print("[03] selesai")
