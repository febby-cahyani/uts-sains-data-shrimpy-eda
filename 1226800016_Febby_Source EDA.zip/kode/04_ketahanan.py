# -*- coding: utf-8 -*-
"""Langkah 04 - uji ketahanan (Bagian D): analisis sensitivitas. Apakah kesimpulan H1-H3 berubah?"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

import config as C
from analisis import agregasi_kondisi, uji_h1, uji_h2, uji_h3
from common import *

fr = pd.read_csv(path_out("02_frame_siap.csv"))
for kol in ("pakai_area", "flag_iqr_out", "flag_ekstrem", "flag_res", "flag_kasar", "ada_label"):
    fr[kol] = fr[kol].astype(bool)
fr["urut"] = fr.groupby("kond_id").cumcount()


def skenario():
    s = {"S0 utama": fr.copy()}
    f = fr.copy(); f["pakai_area"] &= ~f["flag_iqr_out"]; s["S1 tanpa outlier IQR luas box"] = f
    s["S2 tanpa citra resolusi non-standar"] = fr[~fr["flag_res"]].copy()
    s["S3 tanpa alas Hitam"] = fr[fr["warna_bg"] != "Hitam"].copy()
    f = fr.copy(); f["pakai_area"] &= ~f["flag_kasar"]; s["S4 tanpa polygon kasar (<=5 titik)"] = f
    s[f"S5 subsampel tiap-{C.SUBSAMPLE_K} frame"] = fr[(fr["urut"] % C.SUBSAMPLE_K) == 0].copy()
    f = fr.copy(); f["pakai_area"] = f["ada_label"]; s["S6 tanpa membuang outlier ekstrem"] = f
    return s


def ringkas(f, n_min=None):
    kd = agregasi_kondisi(f, n_min)
    r = dict(n_kondisi_area=int(kd["median_area_frac"].notna().sum()), n_pasangan_blur=0)
    h1 = uji_h1(kd)
    if h1:
        m = h1["medians"]
        r.update(h1_p=h1["p"], h1_eps2=h1["eps2"], h1_rasio_M_S=m[1] / m[0], h1_rasio_L_M=m[2] / m[1], h1_urut=bool(m[0] < m[1] < m[2]))
    h2 = uji_h2(kd)
    for nama, pre in (("mentah", "h2m"), ("ternormalkan", "h2n")):
        x = h2[nama]["semua"]
        r.update({f"{pre}_rasio": x["rasio"], f"{pre}_ci_lo": x["ci_lo"], f"{pre}_ci_hi": x["ci_hi"], f"{pre}_p": x["p"]})
        r["n_pasangan_blur"] = x["n"]
    h3 = uji_h3(kd)["semua"]
    r.update(h3_rasio=h3["rasio"], h3_ci_lo=h3["ci90_lo"], h3_ci_hi=h3["ci90_hi"], h3_ekuivalen=h3["ekuivalen_ci"])
    return r


rows = []
for nama, f in skenario().items():
    print("   skenario:", nama, f"({len(f):,} frame)")
    nm = max(3, int(np.ceil(C.N_MIN_LABEL / C.SUBSAMPLE_K))) if nama.startswith("S5") else None   # ambang frame ikut diskalakan
    rows.append(dict(skenario=nama, n_frame=len(f), **ringkas(f, nm)))
t = pd.DataFrame(rows)
b = t.iloc[0]


def sig(p):
    return bool(p < C.ALPHA) if p == p else None


def berubah(r):
    msg = []
    if sig(r.get("h1_p", np.nan)) != sig(b.get("h1_p", np.nan)) or r.get("h1_urut") != b.get("h1_urut"):
        msg.append("H1")
    for pre in ("h2m", "h2n"):
        if sig(r[f"{pre}_p"]) != sig(b[f"{pre}_p"]) or (np.sign(np.log(r[f"{pre}_rasio"])) != np.sign(np.log(b[f"{pre}_rasio"]))):
            msg.append(pre.upper())
    if r["h3_ekuivalen"] != b["h3_ekuivalen"]:
        msg.append("H3")
    return ", ".join(msg) if msg else "tidak berubah"


t["kesimpulan_berubah"] = t.apply(berubah, axis=1)
simpan_csv(t, "D_sensitivitas.csv")

# margin ekuivalensi
kd0 = agregasi_kondisi(fr)
mm = []
for m in (0.05, 0.10, 0.15, 0.20):
    r = uji_h3(kd0, margin=m)["semua"]
    mm.append(dict(margin_pct=100 * m, rasio=r["rasio"], ci90_lo=r["ci90_lo"], ci90_hi=r["ci90_hi"], ekuivalen=r["ekuivalen_ci"], p_tost=r["p_tost"]))
simpan_csv(pd.DataFrame(mm), "D_margin_ekuivalensi.csv")

# pseudoreplikasi: uji tingkat frame vs tingkat kondisi (H2 mentah)
rng = np.random.default_rng(C.SEED)
a = fr.loc[fr["posisi_lampu"] == "Atas", "log_blur"].to_numpy()
bw = fr.loc[fr["posisi_lampu"] == "Bawah", "log_blur"].to_numpy()
sub_a, sub_b = rng.choice(a, min(len(a), 50000), replace=False), rng.choice(bw, min(len(bw), 50000), replace=False)
pf = stats.mannwhitneyu(sub_b, sub_a, alternative="two-sided").pvalue
ps = pd.DataFrame([dict(tingkat="frame (pseudoreplikasi)", n_unit=len(sub_a) + len(sub_b), p=pf, cliffs_delta=cliffs_delta(sub_b, sub_a)),
                   dict(tingkat="kondisi (utama)", n_unit=int(b["n_pasangan_blur"]) * 2, p=b["h2m_p"], cliffs_delta=np.nan)])
simpan_csv(ps, "D_pseudoreplikasi.csv")

# gambar
fig, ax = plt.subplots(1, 3, figsize=(15, 4.5), sharey=True)
y = np.arange(len(t))
for a_, (pre, ju, lo, hi) in zip(ax, [("h2m", "H2 mentah: rasio Bawah/Atas", "h2m_ci_lo", "h2m_ci_hi"), ("h2n", "H2 ternormalkan", "h2n_ci_lo", "h2n_ci_hi"), ("h3", "H3: rasio luas box Bawah/Atas (CI90%)", "h3_ci_lo", "h3_ci_hi")]):
    est = t[f"{pre}_rasio"].to_numpy()
    a_.errorbar(est, y, xerr=[est - t[lo].to_numpy(), t[hi].to_numpy() - est], fmt="o", color="#4A3FAE", capsize=3)
    a_.axvline(1, color="k", lw=0.8); a_.set_title(ju, fontsize=10)
    if pre == "h3":
        a_.axvspan(1 / (1 + C.TOST_MARGIN), 1 + C.TOST_MARGIN, color="#DCE4FF", alpha=0.7)
ax[0].set_yticks(y); ax[0].set_yticklabels(t["skenario"], fontsize=8); ax[0].invert_yaxis()
plt.tight_layout(); plt.savefig(path_out("D_sensitivitas_forest.png"), dpi=180); plt.close()
print("   gambar: D_sensitivitas_forest.png")

ring = ["# Ringkasan ketahanan (otomatis)", ""]
for r in t.itertuples():
    ring.append(f"- {r.skenario}: H1 p={getattr(r, 'h1_p', np.nan):.2g}; H2 mentah {r.h2m_rasio:.2f}x; H2 ternormalkan {r.h2n_rasio:.2f}x; H3 {r.h3_rasio:.3f} (ekuivalen={r.h3_ekuivalen}) -> kesimpulan: {r.kesimpulan_berubah}")
ring.append(f"\nPseudoreplikasi: uji tingkat frame p={pf:.2g} (n={len(sub_a) + len(sub_b):,}) vs tingkat kondisi p={b['h2m_p']:.2g} (n pasangan={int(b['n_pasangan_blur'])}).")
open(path_out("D_ringkasan.md"), "w", encoding="utf-8").write("\n".join(ring) + "\n")
print("[04] selesai")
