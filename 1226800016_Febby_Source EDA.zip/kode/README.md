# Tindak Lanjut EDA: pipeline dari data mentah sampai hasil akhir

Proyek UTS Sains Data (S2 TIK PENS): tindak lanjut EDA citra udang vaname pada baseline air jernih 0,5 NTU.
Satu perintah menjalankan seluruh alur: **data mentah (citra + label VIA JSON) -> persiapan data -> uji hipotesis -> uji ketahanan**.

## Struktur

| Berkas | Fungsi | Bagian soal |
|---|---|---|
| `config.py` | semua path dan parameter (ubah di sini) | E |
| `common.py`, `analisis.py` | fungsi bersama (parsing nama, bootstrap, uji) | - |
| `01_ekstraksi.py` | citra + label JSON -> tabel per citra (`01_citra.csv`) | B |
| `02_persiapan_data.py` | missing value, outlier, transformasi, unit analisis, split per kondisi | B |
| `03_uji_hipotesis.py` | H1, H2, H3 dengan cek asumsi dan ukuran efek | C |
| `04_ketahanan.py` | analisis sensitivitas (7 skenario), margin ekuivalensi, pseudoreplikasi | D |
| `run_all.py` | menjalankan semuanya berurutan | E |
| `buat_data_sintetis.py` | dataset sintetis kecil untuk uji coba (bukan data penelitian) | E |

## Cara menjalankan

```
pip install -r requirements.txt
python run_all.py --demo                  # uji coba 10 detik pada data sintetis (tanpa data asli)
python run_all.py                         # data asli: atur path di config.py dulu
python run_all.py --lewati-ekstraksi      # pakai 01_citra.csv yang sudah ada (melewati pembacaan 187 ribu citra)
```

Memakai tabel hasil EDA sebelumnya: salin `eda_blur_per_citra.csv` ke folder `OUT_DIR` dengan nama `01_citra.csv`
(kolom kecerahan dan jumlah titik polygon dilengkapi otomatis bila ada `eda_luas_polygon_per_frame.csv`).

Kebutuhan: Python 3.10+, paket di `requirements.txt`. Versi yang diuji: pandas 3.0, scipy 1.17, OpenCV 4.13, seaborn 0.13.

## Parameter (config.py)

| Parameter | Arti | Bawaan |
|---|---|---|
| `SEED` | benih acak (bootstrap, split) | 42 |
| `IQR_K` | pengali IQR untuk outlier luas box | 1,5 |
| `EKSTREM_FRAC` | box > fraksi ini dari luas frame dianggap diduga salah label | 0,50 |
| `N_MIN_LABEL` | minimal frame berlabel per kondisi agar ikut analisis ukuran | 30 |
| `TOST_MARGIN` | batas ekuivalensi H3 (selisih luas box lampu Bawah vs Atas) | 0,10 |
| `SUBSAMPLE_K` | skenario S5: ambil tiap-k frame | 30 |
| `N_BOOT` | ulangan bootstrap | 5000 |
| `SAMPLE_PER_FOLDER` | langkah 01: sampel acak per folder (None = semua) | None |

**Mengubah satu parameter lalu menjalankan ulang** (mis. margin ekuivalensi 10% -> 5%): ubah `TOST_MARGIN = 0.05`,
lalu `python run_all.py --lewati-ekstraksi`. Yang berubah: `C_hasil_uji.csv` (baris H3), `C_H3_ekuivalensi.png`, `D_margin_ekuivalensi.csv`.

## Keluaran (folder OUT_DIR)

- **Bagian B:** `B_missing_audit.csv`, `B_keputusan.csv` (apa, mengapa, risiko), `B_sebelum_sesudah.csv` + `B_sebelum_sesudah_luas.png`, `B_sebelum_sesudah_blur.png`, `B_autokorelasi.csv`, `B_split_audit.csv`, `02_split_kondisi.csv`, `02_frame_siap.csv`, `02_kondisi.csv`.
- **Bagian C:** `C_hasil_uji.csv`, `C_asumsi.csv`, `C_ringkasan.md`, `C_H1_median_per_kelas.png`, `C_H2_selisih_berpasangan.png`, `C_H3_ekuivalensi.png`.
- **Bagian D:** `D_sensitivitas.csv`, `D_ringkasan.md`, `D_margin_ekuivalensi.csv`, `D_pseudoreplikasi.csv`, `D_sensitivitas_forest.png`.

## Desain analisis (ringkas)

- **Unit analisis = kondisi** (kelas x warna alas x posisi lampu x PWM), bukan frame. Frame bersebelahan berurutan (autokorelasi pada `B_autokorelasi.csv`), sehingga uji tingkat frame menggembungkan signifikansi; `D_pseudoreplikasi.csv` menunjukkannya.
- **H1** (luas box relatif terurut Small < Medium < Large): Kruskal-Wallis + Jonckheere-Terpstra; pasangan kelas dengan Mann-Whitney, koreksi Holm, ukuran efek epsilon-kuadrat dan Cliff's delta (CI bootstrap).
- **H2** (lampu Bawah menaikkan skor ketajaman): Wilcoxon berpasangan pada pasangan kondisi yang sama kecuali posisi lampu; dilaporkan pada skor mentah dan skor ternormalkan kecerahan; ukuran efek rasio median (CI bootstrap) dan rank-biserial.
- **H3** (lampu tidak menggeser luas box lebih dari +-margin): uji ekuivalensi (TOST) berbasis Wilcoxon + CI90% bootstrap terhadap margin. Margin adalah keputusan penelitian; sensitivitasnya di `D_margin_ekuivalensi.csv`.
- **Sensitivitas:** tanpa outlier IQR, tanpa resolusi non-standar, tanpa alas Hitam, tanpa polygon kasar, subsampel tiap-k frame, tanpa membuang outlier ekstrem; kolom `kesimpulan_berubah` menandai H yang berubah.

## Keterbatasan kode

- Data penelitian tidak disertakan; `--demo` memakai data sintetis dengan efek yang diatur (hanya untuk menguji bahwa kode berjalan, hasilnya bukan temuan).
- Kondisi tanpa label (mis. alas Hitam, Hijau-Atas) tidak ikut H1 dan H3; H2 tidak butuh label sehingga memakai semua kondisi.
- Asumsi kesimetrisan uji Wilcoxon dilaporkan pada `C_asumsi.csv`; CI bootstrap tidak memakai asumsi itu.

## Pernyataan penggunaan AI

Claude (Anthropic) dipakai untuk membantu menulis dan menguji kode serta menyusun draf laporan. Seluruh kode dijalankan
pada data penelitian oleh penulis, dan hasilnya diverifikasi serta ditafsirkan oleh penulis.
(Sesuaikan kalimat ini dengan bagian yang benar-benar dibantu.)
