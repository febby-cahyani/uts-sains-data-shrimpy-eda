# -*- coding: utf-8 -*-
"""Fungsi analisis bersama (dipakai langkah 03 dan 04)."""
import numpy as np
import pandas as pd
from scipy import stats

import config as C
from common import KOND, URUT, boot_cliffs_ci, boot_median_ci, cliffs_delta


def agregasi_kondisi(fr, n_min=None):
    """Satu baris per kondisi (unit analisis). Blur memakai semua frame; luas box hanya frame `pakai_area`."""
    n_min = C.N_MIN_LABEL if n_min is None else n_min
    k = fr.groupby(KOND).agg(n_frame=("filename", "size"), mean_log_blur=("log_blur", "mean"),
                             mean_log_blur_norm=("log_blur_norm", "mean"), mean_brightness=("brightness", "mean")).reset_index()
    a = (fr[fr["pakai_area"]].groupby(KOND).agg(n_label=("log_area", "size"), mean_log_area=("log_area", "mean"),
                                                  median_area_frac=("box_area_frac", "median")).reset_index())
    k = k.merge(a, on=KOND, how="left")
    k["n_label"] = k["n_label"].fillna(0).astype(int)
    k.loc[k["n_label"] < n_min, ["mean_log_area", "median_area_frac"]] = np.nan
    return k


def _rank_biserial(d):
    d = d[d != 0]
    if len(d) == 0:
        return np.nan
    r = stats.rankdata(np.abs(d))
    wp, wm = r[d > 0].sum(), r[d < 0].sum()
    return float((wp - wm) / (wp + wm))


def jonckheere(groups):
    n = np.array([len(g) for g in groups])
    N = n.sum()
    jt = 0.0
    for i in range(len(groups)):
        for j in range(i + 1, len(groups)):
            x = np.sort(groups[j])
            for v in groups[i]:
                sr, sl = np.searchsorted(x, v, "right"), np.searchsorted(x, v, "left")
                jt += (len(x) - sr) + 0.5 * (sr - sl)
    mu = (N ** 2 - (n ** 2).sum()) / 4
    var = (N ** 2 * (2 * N + 3) - (n ** 2 * (2 * n + 3)).sum()) / 72
    z = (jt - mu) / np.sqrt(var)
    return float(jt), float(z), float(1 - stats.norm.cdf(z))


def uji_h1(k):
    """H1: luas box relatif berbeda dan terurut Small < Medium < Large (unit = kondisi)."""
    d = k.dropna(subset=["median_area_frac"])
    gr = [d.loc[d["ukuran_kelas"] == c, "median_area_frac"].to_numpy() for c in URUT]
    n = [len(g) for g in gr]
    if min(n) < 3:
        return None
    H, p = stats.kruskal(*gr)
    N = sum(n)
    eps2 = max((H - 3 + 1) / (N - 3), 0.0)
    lev = stats.levene(*[np.log(g) for g in gr], center="median")
    jt, z, pjt = jonckheere(gr)
    pair = []
    for i, j in [(0, 1), (1, 2), (0, 2)]:
        u, pu = stats.mannwhitneyu(gr[j], gr[i], alternative="two-sided")
        dl = cliffs_delta(gr[j], gr[i])
        lo, hi = boot_cliffs_ci(gr[j], gr[i])
        pair.append(dict(a=URUT[i], b=URUT[j], rasio_median=float(np.median(gr[j]) / np.median(gr[i])),
                         cliffs_delta=dl, d_lo=lo, d_hi=hi, p=float(pu)))
    return dict(n=n, H=float(H), p=float(p), eps2=float(eps2), levene_p=float(lev.pvalue), jt_z=z, jt_p=pjt,
                medians=[float(np.median(g)) for g in gr], pair=pair, grup=gr)


def _pasangan(k, kolom):
    w = k.pivot_table(index=["ukuran_kelas", "warna_bg", "pwm_cahaya"], columns="posisi_lampu", values=kolom)
    if not {"Atas", "Bawah"} <= set(w.columns):
        return pd.Series(dtype=float)
    w = w.dropna(subset=["Atas", "Bawah"])
    return w["Bawah"] - w["Atas"]


def ringkas_pasangan(d, alpha=None):
    """d = selisih berpasangan pada skala log (Bawah - Atas)."""
    d = np.asarray(d, float)
    d = d[~np.isnan(d)]
    out = dict(n=len(d), median_d=np.nan, rasio=np.nan, ci_lo=np.nan, ci_hi=np.nan, p=np.nan, r_rb=np.nan, shapiro_p=np.nan)
    if len(d) < 6:
        return out
    lo, hi = boot_median_ci(d)
    try:
        p = float(stats.wilcoxon(d).pvalue)
    except ValueError:
        p = np.nan
    out.update(median_d=float(np.median(d)), rasio=float(np.exp(np.median(d))), ci_lo=float(np.exp(lo)), ci_hi=float(np.exp(hi)),
               p=p, r_rb=_rank_biserial(d), shapiro_p=float(stats.shapiro(d).pvalue))
    return out


def uji_h2(k):
    """H2: lampu Bawah menaikkan skor ketajaman (mentah) - dan apakah efeknya bertahan setelah kecerahan dinormalkan."""
    hasil = {}
    for nama, kol in [("mentah", "mean_log_blur"), ("ternormalkan", "mean_log_blur_norm")]:
        d = _pasangan(k, kol)
        hasil[nama] = dict(semua=ringkas_pasangan(d.to_numpy()), d=d)
        for c in URUT:
            sub = d[d.index.get_level_values("ukuran_kelas") == c] if len(d) else d
            hasil[nama][c] = ringkas_pasangan(sub.to_numpy())
    return hasil


def uji_h3(k, margin=None):
    """H3 (ekuivalensi/TOST): lampu Bawah vs Atas TIDAK menggeser luas box relatif lebih dari +-margin."""
    margin = C.TOST_MARGIN if margin is None else margin
    delta = float(np.log(1 + margin))
    d = _pasangan(k, "mean_log_area")
    hasil = {"margin": margin, "delta": delta, "d": d}

    def satu(x):
        x = np.asarray(x, float)
        x = x[~np.isnan(x)]
        r = dict(n=len(x), rasio=np.nan, ci90_lo=np.nan, ci90_hi=np.nan, p_tost=np.nan, ekuivalen_ci=np.nan, ekuivalen_p=np.nan)
        if len(x) < 6:
            return r
        lo, hi = boot_median_ci(x, alpha=0.10)
        try:
            p1 = stats.wilcoxon(x - delta, alternative="less").pvalue
            p2 = stats.wilcoxon(x + delta, alternative="greater").pvalue
            ptost = float(max(p1, p2))
        except ValueError:
            ptost = np.nan
        r.update(rasio=float(np.exp(np.median(x))), ci90_lo=float(np.exp(lo)), ci90_hi=float(np.exp(hi)), p_tost=ptost,
                 ekuivalen_ci=bool(lo > -delta and hi < delta), ekuivalen_p=bool(ptost < C.ALPHA) if ptost == ptost else np.nan)
        return r

    hasil["semua"] = satu(d.to_numpy())
    for c in URUT:
        sub = d[d.index.get_level_values("ukuran_kelas") == c] if len(d) else d
        hasil[c] = satu(sub.to_numpy())
    return hasil
