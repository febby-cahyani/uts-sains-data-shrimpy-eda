# -*- coding: utf-8 -*-
"""Membuat dataset SINTETIS kecil (bukan data penelitian) agar seluruh pipeline bisa diuji tanpa data asli.
Dijalankan otomatis oleh:  python run_all.py --demo"""
import json
import os

import cv2
import numpy as np

import config as C
from common import *

rng = np.random.default_rng(0)
W, H, N_IMG = 192, 108, 40
PREF = {"small": "K_", "medium": "", "large": "L_"}
AREA = {"small": 0.04, "medium": 0.08, "large": 0.13}      # luas box relatif (tidak dipengaruhi lampu)
n_img = 0
for fk, kelas in SIZE_FOLDERS.items():
    for warna in sorted(WARNA):
        W_ = warna.capitalize()
        for pos in ("A", "B"):
            for pwm in sorted(PWM_OK):
                w_, h_ = (256, 144) if (kelas == "small" and warna == "putih" and pos == "A" and pwm == 255) else (W, H)
                nama_folder = f"{PREF[kelas]}{W_}_{pos}_{pwm}"
                d = os.path.join(C.IMG_DIR, fk, nama_folder)
                os.makedirs(d, exist_ok=True)
                terang = 40 + pwm * 0.35 + (30 if pos == "B" else 0) - (20 if warna == "hitam" else 0)
                data, label_ada = {}, not (warna == "hitam" or (warna == "hijau" and pos == "A"))
                for i in range(1, N_IMG + 1):
                    nm = f"{PREF[kelas]}{W_}_{pos}_{pwm}_20260101_000000_{i:03d}.jpg"
                    g = np.clip(terang + rng.normal(0, 25, (h_, w_)), 0, 255).astype(np.uint8)
                    if pos == "A":
                        g = cv2.GaussianBlur(g, (0, 0), 1.2)
                    cv2.imwrite(os.path.join(d, nm), cv2.merge([g, g, g]))
                    n_img += 1
                    if label_ada and i > 10:
                        frac = float(np.clip(AREA[kelas] * (1 + 0.15 * rng.normal()), 0.01, 0.4))
                        if rng.random() < 0.01:
                            frac = 0.6                                   # sengaja: diduga salah label
                        lebar = np.sqrt(frac * w_ * h_ * 2)
                        tinggi = lebar / 2
                        cx, cy = w_ / 2, h_ / 2
                        t = np.linspace(0, 2 * np.pi, 12, endpoint=False)
                        xs, ys = cx + lebar / 2 * np.cos(t), cy + tinggi / 2 * np.sin(t)
                        data[nm] = {"filename": nm, "size": 0, "regions": {"0": {
                            "shape_attributes": {"name": "polygon", "all_points_x": xs.tolist(), "all_points_y": ys.tolist()},
                            "region_attributes": {"label": f"{kelas.capitalize()} Shrimp"}}}}
                if data:
                    jd = os.path.join(C.LBL_DIR, f"{W_}_{pos}")
                    os.makedirs(jd, exist_ok=True)
                    with open(os.path.join(jd, f"{kelas}_{W_}_{pos}_{pwm}.json"), "w") as f:
                        json.dump(data, f)
print(f"[demo] dataset sintetis dibuat: {n_img:,} citra di {C.IMG_DIR}")
