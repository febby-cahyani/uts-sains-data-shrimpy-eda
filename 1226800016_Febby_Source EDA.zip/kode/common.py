# -*- coding: utf-8 -*-
import os
import re

import numpy as np
import pandas as pd

import config as C

KELAS = {"small": "Small (4-7 cm)", "medium": "Medium (8-10 cm)", "large": "Large (11-15 cm)"}
URUT = list(KELAS.values())
KEY_OF = {v: k for k, v in KELAS.items()}
SIZE_FOLDERS = {"Small_Shrimp": "small", "Medium_Shrimp": "medium", "Large_Shrimp": "large"}
WARNA = {"abu", "biru", "hijau", "hitam", "krem", "kuning", "merah", "putih"}
ALIAS = {"hljau": "hijau"}
PWM_OK = {50, 100, 150, 200, 255}
POSISI = {"a": "Atas", "b": "Bawah"}
KOND = ["ukuran_kelas", "warna_bg", "posisi_lampu", "pwm_cahaya"]
JSON_PAT = re.compile(r"^(?:labels[_-])?(small|medium|large)[_-]([a-z]+)[_-]([ab])[_-](\d+)(?:[_-].*)?$", re.I)


def parse_meta(name):
    tok = [ALIAS.get(t, t) for t in os.path.splitext(os.path.basename(name))[0].lower().split("_")]
    warna = next((t for t in tok if t in WARNA), None)
    posisi = next((t for t in tok if t in ("a", "b")), None)
    if posisi is None and tok and len(tok[0]) == 2 and tok[0][1] in "ab":
        posisi = tok[0][1]
    pwm = next((int(t) for t in tok if t.isdigit() and int(t) in PWM_OK), None)
    return warna, posisi, pwm


def meta_from_json_name(path):
    m = JSON_PAT.match(os.path.splitext(os.path.basename(path))[0])
    if not m:
        return None
    kelas, warna, posisi, pwm = m.groups()
    return kelas.lower(), ALIAS.get(warna.lower(), warna.lower()), posisi.lower(), int(pwm)


def path_out(nama):
    os.makedirs(C.OUT_DIR, exist_ok=True)
    return os.path.join(C.OUT_DIR, nama)


def simpan_csv(d, nama, index=False):
    d.to_csv(path_out(nama), index=index)
    print("   tabel :", nama)


def holm(p):
    p = np.asarray(p, float)
    adj = np.full(len(p), np.nan)
    ok = np.where(~np.isnan(p))[0]
    o = ok[np.argsort(p[ok])]
    run, n = 0.0, len(o)
    for r, i in enumerate(o):
        run = max(run, (n - r) * p[i])
        adj[i] = min(run, 1.0)
    return adj


def cliffs_delta(x, y):
    """Positif bila x cenderung lebih besar dari y."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    ys = np.sort(y)
    lt = np.searchsorted(ys, x, side="left").sum()              # pasangan y < x
    gt = (len(ys) - np.searchsorted(ys, x, side="right")).sum()  # pasangan y > x
    return (lt - gt) / (len(x) * len(y))


def boot_median_ci(d, n_boot=None, alpha=0.05, seed=None):
    d = np.asarray(d, float)
    rng = np.random.default_rng(C.SEED if seed is None else seed)
    n_boot = n_boot or C.N_BOOT
    idx = rng.integers(0, len(d), (n_boot, len(d)))
    m = np.median(d[idx], axis=1)
    return float(np.quantile(m, alpha / 2)), float(np.quantile(m, 1 - alpha / 2))


def boot_cliffs_ci(x, y, n_boot=None, alpha=0.05, seed=None):
    rng = np.random.default_rng(C.SEED if seed is None else seed)
    n_boot = min(n_boot or C.N_BOOT, 2000)
    out = np.empty(n_boot)
    for b in range(n_boot):
        out[b] = cliffs_delta(rng.choice(x, len(x)), rng.choice(y, len(y)))
    return float(np.quantile(out, alpha / 2)), float(np.quantile(out, 1 - alpha / 2))
