# -*- coding: utf-8 -*-
"""Semua path dan parameter ada di sini. Ubah satu nilai, jalankan ulang run_all.py."""
import os

DEMO = os.environ.get("EDA_DEMO") == "1"          # True = data sintetis kecil (lihat README)
_HERE = os.path.dirname(os.path.abspath(__file__))

if DEMO:
    IMG_DIR = os.path.join(_HERE, "demo_data", "Raw_Dataset")
    LBL_DIR = os.path.join(_HERE, "demo_data", "Labeling", "Json")
    OUT_DIR = os.path.join(_HERE, "demo_data", "hasil")
    N_MIN_LABEL, SUBSAMPLE_K, N_BOOT = 10, 4, 1000
else:
    IMG_DIR = r"C:\Users\Lenovo\Documents\S2\Program\Dataset\Raw_Dataset"
    LBL_DIR = r"C:\Users\Lenovo\Documents\S2\Program\Dataset\Labeling\Json"
    OUT_DIR = r"C:\Users\Lenovo\Documents\S2\Semester 1\Sains Data\output_eda"
    N_MIN_LABEL = 30        # minimal frame berlabel per kondisi agar ikut analisis ukuran objek
    SUBSAMPLE_K = 30        # skenario sensitivitas: ambil tiap-k frame
    N_BOOT = 5000           # ulangan bootstrap (CI)

# ---- parameter analisis (dipakai di semua langkah) ----
SEED = 42
SAMPLE_PER_FOLDER = None    # langkah 01: None = semua citra, angka = sampel acak per folder kondisi
IQR_K = 1.5                 # pengali IQR untuk outlier luas box
EKSTREM_FRAC = 0.50         # box > 50% luas frame dianggap diduga salah label
TOST_MARGIN = 0.10          # batas ekuivalensi H3: selisih luas box lampu Bawah vs Atas dalam +-10%
ALPHA = 0.05
RES_STANDAR = None          # None = resolusi yang paling sering muncul; atau (1920, 1080)
SPLIT_PROP = (0.70, 0.15, 0.15)   # train / validation / test (per KONDISI, bukan per frame)
