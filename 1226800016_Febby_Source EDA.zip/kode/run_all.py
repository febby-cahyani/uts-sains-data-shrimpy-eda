# -*- coding: utf-8 -*-
"""Menjalankan seluruh pipeline: data mentah -> persiapan -> uji hipotesis -> uji ketahanan.
  python run_all.py                       # data asli (path di config.py)
  python run_all.py --lewati-ekstraksi    # pakai 01_citra.csv yang sudah ada (langkah 01 lama)
  python run_all.py --demo                # data sintetis kecil, untuk uji coba cepat"""
import argparse
import os
import subprocess
import sys
import time

ap = argparse.ArgumentParser()
ap.add_argument("--demo", action="store_true")
ap.add_argument("--lewati-ekstraksi", action="store_true")
a = ap.parse_args()
here = os.path.dirname(os.path.abspath(__file__))
env = dict(os.environ)
if a.demo:
    env["EDA_DEMO"] = "1"
    os.environ["EDA_DEMO"] = "1"
sys.path.insert(0, here)
import config as C

langkah = ["01_ekstraksi.py", "02_persiapan_data.py", "03_uji_hipotesis.py", "04_ketahanan.py"]
if a.demo and not os.path.isdir(C.IMG_DIR):
    subprocess.run([sys.executable, os.path.join(here, "buat_data_sintetis.py")], check=True, cwd=here, env=env)
if a.lewati_ekstraksi:
    langkah = langkah[1:]
t0 = time.time()
for f in langkah:
    print(f"\n===== {f} =====")
    subprocess.run([sys.executable, os.path.join(here, f)], check=True, cwd=here, env=env)
print(f"\nSelesai dalam {time.time() - t0:.0f} detik. Hasil ada di: {C.OUT_DIR}")
